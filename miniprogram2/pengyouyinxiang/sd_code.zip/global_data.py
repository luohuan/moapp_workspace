from moapp.server.globals import user, app, page, mo, params
from moapp.server.utils import *
# 小程序全局要引用的变量或者数据

# 匿名头像地址
AVATAR_URL = 'http://material.motimaster.com/appmaker/liyipeng/6901.png'
# 是否是提交审核的版本
IS_AUDIT_VERSION = False

# moapp extra lines:2